using Car_dealer.Models;
using Car_dealer.Services;
using Microsoft.AspNetCore.Mvc;

namespace Car_dealer.Controllers
{
    public class AdsController : Controller
    {
        private readonly IWebHostEnvironment environment;

        public AdsController(IWebHostEnvironment environment)
        {
            this.environment = environment;
        }

        public IActionResult Index(string? search, string? brand)
        {
            var ads = FakeDb.Ads.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                ads = ads.Where(a =>
                    a.Title.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    a.Brand.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    a.Model.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrWhiteSpace(brand))
            {
                ads = ads.Where(a => a.Brand.Equals(brand, StringComparison.OrdinalIgnoreCase));
            }

            ViewBag.Search = search;
            ViewBag.Brand = brand;
            ViewBag.Brands = FakeDb.Ads.Select(a => a.Brand).Distinct().OrderBy(b => b).ToList();

            return View(ads.OrderByDescending(a => a.CreatedOn).ThenByDescending(a => a.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var ad = FakeDb.Ads.FirstOrDefault(a => a.Id == id);
            if (ad == null)
            {
                return NotFound();
            }

            return View(ad);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new CreateCarAdViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreateCarAdViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string imageUrl = "/images/no-image.svg";

            if (model.ImageFile != null && model.ImageFile.Length > 0)
            {
                var uploadsFolder = Path.Combine(environment.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadsFolder);

                var safeName = Path.GetFileName(model.ImageFile.FileName);
                var fileName = $"{Guid.NewGuid()}_{safeName}";
                var filePath = Path.Combine(uploadsFolder, fileName);

                await using var stream = new FileStream(filePath, FileMode.Create);
                await model.ImageFile.CopyToAsync(stream);
                imageUrl = $"/uploads/{fileName}";
            }

            var ad = new CarAd
            {
                Id = FakeDb.Ads.Any() ? FakeDb.Ads.Max(a => a.Id) + 1 : 1,
                Title = model.Title,
                Brand = model.Brand,
                Model = model.Model,
                Year = model.Year,
                Price = model.Price,
                FuelType = model.FuelType,
                Category = model.Category,
                Transmission = model.Transmission,
                Mileage = model.Mileage,
                Color = model.Color,
                Description = model.Description,
                ImageUrl = imageUrl,
                SellerName = model.SellerName,
                PhoneNumber = model.PhoneNumber,
                Email = model.Email,
                CreatedOn = DateTime.Now
            };

            FakeDb.Ads.Add(ad);
            return RedirectToAction(nameof(Details), new { id = ad.Id });
        }
    }
}
