using Microsoft.AspNetCore.Mvc;

namespace Car_dealer.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
