using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace Car_dealer.Models
{
    public class CreateCarAdViewModel
    {
        [Required]
        [StringLength(100)]
        [Display(Name = "Заглавие")]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        [Display(Name = "Марка")]
        public string Brand { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        [Display(Name = "Модел")]
        public string Model { get; set; } = string.Empty;

        [Range(1900, 2100)]
        [Display(Name = "Година")]
        public int Year { get; set; } = DateTime.Now.Year;

        [Range(0, 10000000)]
        [Display(Name = "Цена")]
        public decimal Price { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Гориво")]
        public string FuelType { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        [Display(Name = "Категория")]
        public string Category { get; set; } = "Автомобили и Джипове";

        [Required]
        [StringLength(100)]
        [Display(Name = "Скоростна кутия")]
        public string Transmission { get; set; } = string.Empty;

        [Range(0, 2000000)]
        [Display(Name = "Пробег (км)")]
        public int Mileage { get; set; }

        [Required]
        [StringLength(50)]
        [Display(Name = "Цвят")]
        public string Color { get; set; } = string.Empty;

        [Required]
        [StringLength(1000)]
        [Display(Name = "Описание")]
        public string Description { get; set; } = string.Empty;

        [Display(Name = "Снимка")]
        public IFormFile? ImageFile { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Име за контакт")]
        public string SellerName { get; set; } = string.Empty;

        [Required]
        [Phone]
        [Display(Name = "Телефон")]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [Display(Name = "Имейл")]
        public string Email { get; set; } = string.Empty;
    }
}
