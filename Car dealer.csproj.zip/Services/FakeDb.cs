using Car_dealer.Models;

namespace Car_dealer.Services
{
    public static class FakeDb
    {
        public static List<CarAd> Ads { get; set; } = new()
        {
            new CarAd
            {
                Id = 1,
                Title = "BMW X5 3.0d",
                Brand = "BMW",
                Model = "X5",
                Year = 2018,
                Price = 48900,
                FuelType = "Дизел",
                Category = "Автомобили и Джипове",
                Description = "Отлично състояние, автоматик, кожа, навигация.",
                ImageUrl = "/images/no-image.svg"
            },
            new CarAd
            {
                Id = 2,
                Title = "Mercedes C220 CDI",
                Brand = "Mercedes",
                Model = "C220",
                Year = 2017,
                Price = 31900,
                FuelType = "Дизел",
                Category = "Автомобили и Джипове",
                Description = "Добро състояние, реални километри.",
                ImageUrl = "/images/no-image.svg"
            }
        };
    }
}
