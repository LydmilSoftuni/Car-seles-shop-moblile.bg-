using Car_dealer.Models;
using Car_dealer.Services;
using Microsoft.AspNetCore.Mvc;

namespace Car_dealer.Controllers
{
    public class AdsController : Controller
    {
        private readonly IWebHostEnvironment environment;

        public AdsController(IWebHostEnvironment environment)
        {
            this.environment = environment;
        }

        public IActionResult Index(string? category)
        {
            var ads = FakeDb.Ads.AsQueryable();

            if (!string.IsNullOrWhiteSpace(category))
            {
                ads = ads.Where(a => a.Category == category);
            }

            return View(ads.OrderByDescending(a => a.Id).ToList());
        }

        public IActionResult Details(int id)
        {
            var ad = FakeDb.Ads.FirstOrDefault(a => a.Id == id);
            if (ad == null)
            {
                return NotFound();
            }

            return View(ad);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateCarAdViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string imageUrl = "/images/no-image.svg";

            if (model.ImageFile != null && model.ImageFile.Length > 0)
            {
                var uploadsFolder = Path.Combine(environment.WebRootPath, "uploads");

                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(model.ImageFile.FileName)}";
                var filePath = Path.Combine(uploadsFolder, fileName);

                await using var stream = new FileStream(filePath, FileMode.Create);
                await model.ImageFile.CopyToAsync(stream);

                imageUrl = $"/uploads/{fileName}";
            }

            var newAd = new CarAd
            {
                Id = FakeDb.Ads.Any() ? FakeDb.Ads.Max(a => a.Id) + 1 : 1,
                Title = model.Title,
                Brand = model.Brand,
                Model = model.Model,
                Year = model.Year,
                Price = model.Price,
                FuelType = model.FuelType,
                Category = model.Category,
                Description = model.Description,
                ImageUrl = imageUrl
            };

            FakeDb.Ads.Add(newAd);
            return RedirectToAction(nameof(Index));
        }
    }
}
